<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BibleBooks extends Model
{
    protected $fillable = [

        'name_br','name_es'
    ];
}
