<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BibleBooksTexts extends Model
{
    //
}
